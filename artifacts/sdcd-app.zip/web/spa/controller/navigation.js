'use strict';

angular.module('Navigation')
.controller('navigation_controller',[
	'$scope',
	'$location',
	'$timeout',
	'$rootScope',
	'$cookieStore',
	function ($scope,$location,$timeout,$rootScope,$cookieStore) {
		// $scope.home_click = function(){
		// 	window.location.replace('#!home');
		// 	location.reload();
		// }
	}
]);