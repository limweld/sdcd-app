'use strict';

angular.module('Archiver')
.factory('archiver_model',[
	'$http', 
	'$cookieStore',
	function ($http,$cookieStore) {
		
		var service = {};
		
		return service;
	}
]);	