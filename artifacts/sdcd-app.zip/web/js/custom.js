$(document).ready(function(){
    $(".main").click(function(){
    $('#overlay').hide();
    $('#mySidebar').hide();
    });
});